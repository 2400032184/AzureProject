# Azure Subscription Vending & Onboarding – Hackathon Prototype

## What this is
A local working prototype that demonstrates the business workflow of Azure subscription vending without requiring a live Azure subscription.

## Stack
- Frontend: HTML/CSS/JavaScript
- Backend: Java 21 + Spring Boot
- Automation examples: Azure CLI + Bicep
- Demo data: in-memory REST API

## Run
### Backend
1. Install Java 21 and Maven.
2. Open `backend`.
3. Run: `mvn spring-boot:run`
4. Backend starts at http://localhost:8080

### Frontend
Open `frontend/index.html` in a browser.
If the browser blocks local fetches, run a simple server in the frontend folder:
`python -m http.server 5500`
Then open http://localhost:5500

## Demo
1. Dashboard shows existing requests.
2. Open New Request and submit a Travel Booking Portal request.
3. Dashboard → Approve.
4. Click Vend.
5. Show Governance Center.
6. Explain that the prototype simulates the vending engine; the Bicep/CLI files are the bridge to real Azure.

## Important
Do not claim that a real Azure subscription was created. This is a functional local prototype plus Azure implementation artifacts.
